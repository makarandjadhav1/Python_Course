import speedtest_cli

def speedtester():
    st = speedtest_cli.Speedtest()

    print("Loading server list....\n")
    st.get_servers()
    print("Choosing best server....")
    best = st.get_best_server()
    print(f"Found: {best['host']} located in {best['country']}\n")

    option = int(
        input(
            """What speed do you want to test:
            1) Download Speed 
            2) Upload Speed
            3) Ping
            
            Your Choice: """
        )
    )

    if option == 1:
        print("Performing download test...")
        download_result = st.download()
        print(f"Download speed: {download_result / 1024 / 1024:.2f} Mbit/s")

    elif option == 2:
        print("Performing upload test...")
        upload_result = st.upload()
        print(f"Upload speed: {upload_result / 1024 / 1024:.2f} Mbit/s")

    elif option == 3:
        print("Performing ping test...")
        ping_result = st.results.ping
        print(f"Ping: {ping_result:.2f} ms")

    else:
        print("Please enter a correct choice!")

if __name__ == "__main__":
    speedtester()

#pip3 install speedtest_cli or pip3 install speedtest